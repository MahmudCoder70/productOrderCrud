﻿using System.ComponentModel.DataAnnotations.Schema;

namespace creatrix_exam.Models
{
    public class Order
    {
        public int OrderId { get; set; }
        public string ProductName  { get; set; }
        public int Qty { get; set; }
        public decimal U_Price { get; set; }
        public decimal TotalPrice { get; set; }
        [ForeignKey("Customer")]
        public int CustomerId { get; set; }
        public Customer? Customer { get; set; }
    }
}
