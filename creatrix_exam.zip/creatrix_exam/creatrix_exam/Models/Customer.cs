﻿namespace creatrix_exam.Models
{
    public class Customer
    {
        public int CustomerId { get; set; }
        public string CustomerName { get; set; }
        public string MobileNumber { get; set; } // Corrected
        public DateTime PurchaseDate { get; set; }
        public virtual ICollection<Order> Orders { get; set; } = new List<Order>();
    }
}
