﻿namespace creatrix_exam.Models.ViewModels
{
    public class OrderViewModel
    {
        public int? OrderId { get; set; }
        public string ProductName { get; set; }
        public int Qty { get; set; }
        public decimal U_Price { get; set; }
        public decimal TotalPrice { get; set; }
    }
}
