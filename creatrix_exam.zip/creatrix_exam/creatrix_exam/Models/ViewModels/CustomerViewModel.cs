﻿namespace creatrix_exam.Models.ViewModels
{
    public class CustomerViewModel
    {
        public int? CustomerId { get; set; }
        public string CustomerName { get; set; }
        public string MobileNumber { get; set; }
        public DateTime PurchaseDate { get; set; } = DateTime.Now;
        public List<OrderViewModel> Orders { get; set; } = new List<OrderViewModel>();
    }
}
