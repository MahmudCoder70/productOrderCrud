﻿using creatrix_exam.Models;
using creatrix_exam.Models.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace creatrix_exam.Controllers
{
    public class CustomerController : Controller
    {
        private readonly ApplicationDbContext _context;

        public CustomerController(ApplicationDbContext context)
        {
            _context = context;
        }

        // Index (List)
        public async Task<IActionResult> Index()
        {
            //var customers = await _context.Customers.Include(c => c.Orders).ToListAsync();
            //return View(customers);
            var customers = await _context.Customers
            .Include(c => c.Orders)
            .ToListAsync();

            var viewModel = customers.Select(c => new CustomerViewModel
            {
                CustomerId = c.CustomerId,
                CustomerName = c.CustomerName,
                MobileNumber = c.MobileNumber,
                PurchaseDate = c.PurchaseDate,
                Orders = c.Orders.Select(o => new OrderViewModel
                {
                    ProductName = o.ProductName,
                    Qty = o.Qty,
                    U_Price = o.U_Price,
                    TotalPrice = o.TotalPrice
                }).ToList()
            }).ToList();

            return View(viewModel);
        }

        // GET: Create
        public IActionResult Create()
        {
            return View(new CustomerViewModel());
        }

        // POST: Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(CustomerViewModel model)
        {
            if (!ModelState.IsValid) return View(model);

            var customer = new Customer
            {
                CustomerName = model.CustomerName,
                MobileNumber = model.MobileNumber,
                PurchaseDate = model.PurchaseDate,
                Orders = model.Orders.Select(o => new Order
                {
                    ProductName = o.ProductName,
                    Qty = o.Qty,
                    U_Price = o.U_Price,
                    TotalPrice = o.Qty * o.U_Price
                }).ToList()
            };

            _context.Customers.Add(customer);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        // GET: Edit
        public async Task<IActionResult> Edit(int id)
        {
            var customer = await _context.Customers.Include(c => c.Orders).FirstOrDefaultAsync(c => c.CustomerId == id);
            if (customer == null) return NotFound();

            var viewModel = new CustomerViewModel
            {
                CustomerId = customer.CustomerId,
                CustomerName = customer.CustomerName,
                MobileNumber = customer.MobileNumber,
                PurchaseDate = customer.PurchaseDate,
                Orders = customer.Orders.Select(o => new OrderViewModel
                {
                    OrderId = o.OrderId,
                    ProductName = o.ProductName,
                    Qty = o.Qty,
                    U_Price = o.U_Price
                }).ToList()
            };

            return View(viewModel);
        }

        // POST: Edit
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, CustomerViewModel model)
        {
            if (id != model.CustomerId || !ModelState.IsValid)
                return View(model);

            var customer = await _context.Customers.Include(c => c.Orders).FirstOrDefaultAsync(c => c.CustomerId == id);
            if (customer == null) return NotFound();

            customer.CustomerName = model.CustomerName;
            customer.MobileNumber = model.MobileNumber;
            customer.PurchaseDate = model.PurchaseDate;

            // Remove deleted orders
            var existingOrderIds = model.Orders.Where(o => o.OrderId.HasValue).Select(o => o.OrderId.Value).ToList();
            var toRemove = customer.Orders.Where(o => !existingOrderIds.Contains(o.OrderId)).ToList();
            _context.Orders.RemoveRange(toRemove);

            // Update or add orders
            foreach (var o in model.Orders)
            {
                if (o.OrderId.HasValue)
                {
                    var order = customer.Orders.FirstOrDefault(x => x.OrderId == o.OrderId);
                    if (order != null)
                    {
                        order.ProductName = o.ProductName;
                        order.Qty = o.Qty;
                        order.U_Price = o.U_Price;
                        order.TotalPrice = o.Qty * o.U_Price;
                    }
                }
                else
                {
                    customer.Orders.Add(new Order
                    {
                        ProductName = o.ProductName,
                        Qty = o.Qty,
                        U_Price = o.U_Price,
                        TotalPrice = o.Qty * o.U_Price
                    });
                }
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        // GET: Delete
        public async Task<IActionResult> Delete(int id)
        {
            var customer = await _context.Customers.Include(c => c.Orders).FirstOrDefaultAsync(c => c.CustomerId == id);
            if (customer == null) return NotFound();

            return View(customer);
        }

        // POST: Delete
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var customer = await _context.Customers.Include(c => c.Orders).FirstOrDefaultAsync(c => c.CustomerId == id);
            if (customer == null) return NotFound();

            _context.Orders.RemoveRange(customer.Orders);
            _context.Customers.Remove(customer);
            await _context.SaveChangesAsync();

            return RedirectToAction(nameof(Index));
        }

        // GET: Details
        public async Task<IActionResult> Details(int id)
        {
            var customer = await _context.Customers.Include(c => c.Orders).FirstOrDefaultAsync(c => c.CustomerId == id);
            if (customer == null) return NotFound();

            return View(customer);
        }
    }
}
